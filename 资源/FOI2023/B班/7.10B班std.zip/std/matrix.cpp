#include <bits/stdc++.h>
#define For(_, L, R) for(int _ = L; _ <= R; ++_)
using namespace std;
const int MaxN = 1000 + 10;
int N, A[MaxN][MaxN];
int Find[MaxN], D[MaxN];
int F(int N) {
	if(N == Find[N]) return N;
	int Root = F(Find[N]);
	D[N] ^= D[Find[N]];
	return Find[N] = Root;
}
inline void merge(int x, int y, int tag) {
	int u = F(x), v = F(y);
	if(u == v) return;
	D[u] = tag ^ D[x] ^ D[y];
	Find[u] = v;
}
inline void solve() {
	cin >> N;
	For(i, 1, N)
		For(j, 1, N)
			cin >> A[i][j];
	For(i, 0, N)
		Find[i] = i, D[i] = 0;
	For(i, 1, N - 1)
		For(j, i + 1, N)
			if(A[i][j] > A[j][i])
				merge(i, j, 1);
			else if(A[i][j] < A[j][i])
				merge(i, j, 0);
	For(i, 1, N) F(i);
	For(i, 1, N - 1)
		For(j, i + 1, N)
			if(D[i] ^ D[j])
				swap(A[i][j], A[j][i]);
	For(i, 1, N) {
		For(j, 1, N)
			cout << A[i][j] << ' ';
		cout << '\n';
	}
}
int main() {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	solve();
	return 0;
}

