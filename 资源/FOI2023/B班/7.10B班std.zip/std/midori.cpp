#include <bits/stdc++.h>
#define For(_, L, R) for(int _ = L; _ <= R; ++_)
using namespace std;
const int MaxN = 300000 + 10;
int N, M, A[MaxN], Ans[MaxN];
int Q[MaxN], L, R;
int main() {
	freopen("midori.in", "r", stdin);
	freopen("midori.out", "w", stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin >> N >> M;
	For(i, 1, N) cin >> A[i];
	for(int i = N; i >= 1; --i) {
		while(L < R && A[i] >= A[Q[R]]) --R;
		if(L < R && i + M - 1 < Q[L + 1]) ++L;
		Q[++R] = i;
		Ans[i] = R - L;
	}
	For(i, 1, (N - M + 1))
		cout << Ans[i] << ' ';
	cout << '\n';
	return 0;
}

