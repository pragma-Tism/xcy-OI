#include <bits/stdc++.h>
#define For(_, L, R) for(int _ = L; _ <= R; ++_)
using namespace std;
int Stack[1000], Top, N;
const int Mod = 998244353;
char S[1000];
bool fail;
void C(char opt) {
	if(Top < 2) {
		fail = true;
		return;
	}
	int B = Stack[Top--];
	int A = Stack[Top--];
	int Ans;
	if(opt == '+') Ans = (A + B) % Mod;
	if(opt == '-') Ans = (Mod + A - B) % Mod;
	if(opt == '*') Ans = 1ll * A * B % Mod;
	Stack[++Top] = Ans;
}
int main() {
	freopen("calc.in", "r", stdin);
	freopen("calc.out", "w", stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin >> S;
	N = strlen(S);
	For(i, 0, N - 1) {
		if('0' <= S[i] && S[i] <= '9') Stack[++Top] = S[i] - '0';
			else C(S[i]);
		if(fail) break;
	}
	if(fail || Top != 1) cout << "0\n0\n";
		else cout << "1\n" << Stack[1] << '\n';
	return 0;
}

