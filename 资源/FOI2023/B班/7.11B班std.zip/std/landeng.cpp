#include <bits/stdc++.h>
using namespace std;
#define For(_,l,r) for(int _ = l; _ <= r; ++_)
template <class R> inline bool Checkmax(R &A, R B) {
	return A < B ? A = B, 1 : 0;
}
template <class R> inline bool Checkmin(R &A, R B) {
	return A > B ? A = B, 1 : 0;
}
template <class R> inline R Lowbit(R A) {
	return A & -A;
}
const int MaxN = 250000 + 10;
const int MaxNod = 2200000 + 10;
const int N = 500010;
int Q;
int Opt[MaxN];
pair<int, pair<int, int> > P[MaxN];
int Time[MaxN];
bool Topt[MaxN]; // isTrueOperation: is there a new item added?
map<pair<int, pair<int, int> > , pair<int, int>> Map;
vector<pair<int, pair<int, int> > > Opts[MaxNod];
#define Mid ((L+R)>>1)
#define Ls (Nod<<1)
#define Rs (Nod<<1|1)
// the divide-and-conquer segment tree
void Modify(int Nod, int L, int R, int Ql, int Qr, int Id) {
	if(L == Ql and R == Qr) {
		Opts[Nod].push_back(P[Id]);
		return;
	}
	if(Qr <= Mid) Modify(Ls, L, Mid, Ql, Qr, Id);
		else if(Ql > Mid) Modify(Rs, Mid + 1, R, Ql, Qr, Id);
			else Modify(Ls, L, Mid, Ql, Mid, Id), Modify(Rs, Mid + 1, R, Mid + 1, Qr, Id);
}
int Answer[MaxN];
int Size[2];
// the modify-query segment tree
struct segmentTree {
	int Min[MaxNod];
	void Modify(int Nod, int L, int R, int Pos, int Val) {
		if(L == R) {
			Min[Nod] = Val;
			return;
		}
		if(Pos <= Mid) Modify(Ls, L, Mid, Pos, Val);
			else Modify(Rs, Mid + 1, R, Pos, Val);
		Min[Nod] = min(Min[Ls], Min[Rs]);
	}
	int Query(int Nod, int L, int R, int xmy, int Fmin) {
		/*
			xmy: 	x minus y in this query
			Fmin: 	former-min, which means min on [1, L-1]
					min(Fmin, Min[Ls]) = min on [1, Mid]
		*/
		if(L == R) return L;
		if(min(Fmin, Min[Ls]) <= Mid + xmy) return Query(Ls, L, Mid, xmy, Fmin);
			else return Query(Rs, Mid + 1, R, xmy, min(Fmin, Min[Ls]));
	}
} Seg[2];
int Min[2][MaxN]; // for the same A, only minimum B is useful
vector<pair<int, pair<int, int> > > Rollback[MaxNod];
void Solve(int Nod, int L, int R, int Ans) {
	for(auto opts : Opts[Nod]) { // add new items
		int t = opts.first, x = opts.second.first, y = opts.second.second;
		if(Min[t][x] <= y) continue;
		opts.second.second = Min[t][x];
		Rollback[Nod].push_back(opts);
		Min[t][x] = y;
		Seg[t].Modify(1, 1, N, x, y);
		++Size[t];
		if(max(x, y) >= Ans or Size[0] == 0 or Size[1] == 0) continue;
		Checkmin(Ans, Seg[t^1].Query(1, 1, N, x - y, N) + x);
	}
	if(L == R) { // divide and conquer - leaf
		if(Size[0] and Size[1]) Answer[L] = Ans - 2; // as we have +1 on A and B
			else Answer[L] = -1;
	} else { // divide and conquer
		Solve(Ls, L, Mid, Ans);
		Solve(Rs, Mid + 1, R, Ans);
	}
	for(auto r : Rollback[Nod]) { // rollback
		int t = r.first, x = r.second.first, y = r.second.second;
		Min[t][x] = y;
		Seg[t].Modify(1, 1, N, x, y);
		--Size[t];
	}
}
int main() {
	freopen("landeng.in", "r", stdin);
	freopen("landeng.out", "w", stdout);
	// init
	memset(Min, 63, sizeof Min);
	memset(Seg[0].Min, 63, sizeof Seg[0].Min);
	memset(Seg[1].Min, 63, sizeof Seg[1].Min);
	// input
	scanf("%d", &Q);
	For(i, 1, Q) {
		scanf("%d%d%d%d", &Opt[i], &P[i].first, &P[i].second.first, &P[i].second.second);
		--P[i].first;
		++P[i].second.first;
		++P[i].second.second; // A += 1 and B += 1 to remove annoying zeros
		if(Opt[i] == 1) { // add an item
			pair<int, int> Reg = Map[P[i]];
			if(Reg.first == 0) {
				Map[P[i]] = make_pair(1, i); // reserve the id of the item
				Topt[i] = true; // add a new item in this operation
			} else {
				++Reg.first;
				Map[P[i]] = Reg;
			}
		} else { // remove an item
			pair<int, int> Reg = Map[P[i]];
			assert(Reg.first != 0);
			--Reg.first;
			if(Reg.first == 0) Time[Reg.second] = i; // reserve the deleting time of the item
			Map[P[i]] = Reg;
		}
	}
	// add time-segments to the divide-and-conquer segment tree
	For(i, 1, Q)
		if(Topt[i]) {
			if(not Time[i]) Time[i] = Q + 1;
			Modify(1, 1, Q, i, Time[i] - 1, i);
		}
	Solve(1, 1, Q, N);
	for(int i = 1; i <= Q; ++i)
		printf("%d\n", Answer[i]);
	return 0;
}
