#include <bits/stdc++.h>
using namespace std;
#define For(_,l,r) for(int _ = l; _ <= r; ++_)
const int MaxN = 540000 + 10;
struct things {
	bool a;
	int b, Id;
	void In(int id) {
		cin >> a >> b;
		Id = id;
	}
} T[MaxN];
inline bool Cmp(things A, things B) {
	return A.b == B.b ? A.a > B.a : A.b < B.b;
}
inline bool Cmp2(things A, things B) {
	return A.Id < B.Id;
}
int N;
int Pos[MaxN];
int Lb[MaxN], Rb[MaxN], Sum[MaxN];
#define Mid ((L + R) >> 1)
#define Ls (Nod << 1)
#define Rs (Nod << 1 | 1)
inline void Update(int Nod) {
	Sum[Nod] = Sum[Ls] + Sum[Rs] + min(Lb[Ls], Rb[Rs]);
	Lb[Nod] = Lb[Rs] + max(0, Lb[Ls] - Rb[Rs]);
	Rb[Nod] = Rb[Ls] + max(0, Rb[Rs] - Lb[Ls]);
}
void Modify(int Nod, int L, int R, int Pos, bool Tag) {
	if(L == R) {
		if(Tag) Lb[Nod] = 1;
			else Rb[Nod] = 1;
	} else {
		if(Pos <= Mid) Modify(Ls, L, Mid, Pos, Tag);
			else Modify(Rs, Mid + 1, R, Pos, Tag);
		Update(Nod);
	}
}
int main() {
	freopen("toy.in", "r", stdin);
	freopen("toy.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin >> N;
	For(i, 1, N) T[i].In(i);
	sort(T + 1, T + 1 + N, Cmp);
	For(i, 1, N) Pos[T[i].Id] = i;
	sort(T + 1, T + 1 + N, Cmp2);
	For(i, 1, N) {
		Modify(1, 1, N, Pos[i], T[i].a);
		cout << Sum[1] << endl;
	}
	return 0;
}

